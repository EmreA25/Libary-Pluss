package dao;

import entity.Student;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class StudentDao {

    public void save(Student student) {
    Transaction transaction = null;
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        transaction = session.beginTransaction();

        // ✅ Elle ID atama (SQLite için)
        Integer nextId = ((Number) session.createNativeQuery("SELECT IFNULL(MAX(id), 0) + 1 FROM students").getSingleResult()).intValue();
        student.setId(nextId);

        session.save(student);
        transaction.commit();
    } catch (Exception e) {
        if (transaction != null) transaction.rollback();
        e.printStackTrace();
    }
}

    @SuppressWarnings("unchecked")
public List<Student> getAll() {
    List<Student> students = new ArrayList<>();
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        List<Object[]> rows = session.createNativeQuery("SELECT id, name, department FROM students").getResultList();

        for (Object[] row : rows) {
            if (row != null) {
                Student s = new Student();
                s.setId(((Number) row[0]).intValue());
                s.setName((String) row[1]);
                s.setDepartment((String) row[2]);
                students.add(s);
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return students;
}

    public Student getById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Student.class, id);
        }
    }

    public void delete(int id) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            Student student = session.get(Student.class, id);
            if (student != null) {
                session.delete(student);
                System.out.println("Öğrenci silindi ✅");
            } else {
                System.out.println("Öğrenci bulunamadı ❌");
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }
}
