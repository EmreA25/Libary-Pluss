package dao;

import entity.Book;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class BookDao {

    public void save(Book book) {
    Transaction transaction = null;
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        transaction = session.beginTransaction();

        // ✅ Elle ID atama (SQLite’ın AUTOINCREMENT desteği için)
        Integer nextId = ((Number) session.createNativeQuery("SELECT IFNULL(MAX(id), 0) + 1 FROM books").getSingleResult()).intValue();
        book.setId(nextId);

        session.save(book);
        transaction.commit();
    } catch (Exception e) {
        if (transaction != null) transaction.rollback();
        e.printStackTrace();
    }
}

    public void update(Book book) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(book);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public void delete(Book book) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.delete(book);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    public Book getById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Book.class, id);
        }
    }

  @SuppressWarnings("unchecked")
public List<Book> getAll() {
    List<Book> books = new ArrayList<>();

    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        // 🔹 Native SQL sorgusu ile ham veriyi alıyoruz
        List<Object[]> rows = session.createNativeQuery("SELECT id, title, author, year, status FROM books").getResultList();

        // 🔹 Satırları manuel olarak Book nesnesine çeviriyoruz
        for (Object[] row : rows) {
    if (row == null) continue; // null satır varsa atla

    Book book = new Book();

    // 🔹 ID null olabilir, o yüzden güvenli kontrol
    if (row[0] != null) {
        book.setId(((Number) row[0]).intValue());
    }

    book.setTitle(row[1] != null ? (String) row[1] : "-");
    book.setAuthor(row[2] != null ? (String) row[2] : "-");
    book.setYear(row[3] != null ? ((Number) row[3]).intValue() : 0);

    if (row[4] != null) {
        try {
            book.setStatus(Book.Status.valueOf((String) row[4]));
        } catch (IllegalArgumentException e) {
            book.setStatus(Book.Status.AVAILABLE);
        }
    } else {
        book.setStatus(Book.Status.AVAILABLE);
    }

    books.add(book);
}

    } catch (Exception e) {
        e.printStackTrace();
    }

    return books;
    
}
}
