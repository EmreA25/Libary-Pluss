package dao;

import entity.Book;
import entity.Loan;
import entity.Student;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class LoanDao {

    public void save(Loan loan) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
            session.save(loan);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

   public void update(Loan loan) {
    Transaction tx = null;

    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        tx = session.beginTransaction();
        session.merge(loan); // 🔹 update yerine merge daha güvenli
        tx.commit();
        System.out.println("✅ Loan kaydı başarıyla güncellendi (iade tarihi dahil).");
    } catch (Exception e) {
        if (tx != null && tx.getStatus().canRollback()) {
            try {
                tx.rollback();
            } catch (Exception ex) {
                System.err.println("⚠️ Rollback sırasında hata yoksayıldı: " + ex.getMessage());
            }
        }
        e.printStackTrace();
    }
}

    public List<Loan> getAll() {
        List<Loan> loans = new ArrayList<>();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            @SuppressWarnings("unchecked")
            List<Object[]> rows = session.createNativeQuery(
                    "SELECT l.id, b.title, s.name, l.borrowDate, l.returnDate " +
                    "FROM loans l " +
                    "LEFT JOIN books b ON l.book_id = b.id " +
                    "LEFT JOIN students s ON l.student_id = s.id")
                    .getResultList();

            for (Object[] row : rows) {
                Loan loan = new Loan();

                if (row[0] != null) loan.setId(((Number) row[0]).intValue());
                if (row[3] != null) loan.setBorrowDate((Date) row[3]);
                if (row[4] != null) loan.setReturnDate((Date) row[4]);

                Book book = new Book();
                book.setTitle(row[1] != null ? row[1].toString() : "-");
                loan.setBook(book);

                Student student = new Student();
                student.setName(row[2] != null ? row[2].toString() : "-");
                loan.setStudent(student);

                loans.add(loan);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return loans;
    }

  public Loan getActiveLoanByBookId(int bookId) {
    Loan loan = null;

    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        // ✅ Boş veya null returnDate'e sahip kaydı getir
        String sql = "SELECT id, book_id, student_id, borrowDate, returnDate " +
                     "FROM loans WHERE book_id = :bookId AND (returnDate IS NULL OR TRIM(returnDate) = '') " +
                     "LIMIT 1";

        Object result = session.createNativeQuery(sql)
                .setParameter("bookId", bookId)
                .uniqueResult();

        if (result == null) {
            System.out.println("❗ DEBUG: loans tablosunda aktif kayıt bulunamadı.");
            return null;
        }

        Object[] row = (Object[]) result;
        loan = new Loan();

        if (row[0] != null) loan.setId(((Number) row[0]).intValue());

        if (row[1] != null) {
            Book book = new Book();
            book.setId(((Number) row[1]).intValue());
            loan.setBook(book);
        }

        if (row[2] != null) {
            Student student = new Student();
            student.setId(((Number) row[2]).intValue());
            loan.setStudent(student);
        }

        if (row[3] != null) loan.setBorrowDate((java.sql.Date) row[3]);
        if (row[4] != null) loan.setReturnDate((java.sql.Date) row[4]);

    } catch (Exception e) {
        e.printStackTrace();
    }

    return loan;
}
}
