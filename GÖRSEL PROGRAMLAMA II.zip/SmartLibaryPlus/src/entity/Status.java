package entity;

public enum Status {
    AVAILABLE,
    BORROWED
}
