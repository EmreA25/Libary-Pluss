package entity;

import javax.persistence.*;

@Entity
@Table(name = "books")
public class Book {

 @Id
@Column(name = "id", nullable = false)
private Integer id;


    @Column(name = "title") // 🔹 başlık sütunu
    private String title;

    @Column(name = "author") // 🔹 yazar sütunu
    private String author;

    @Column(name = "year") // 🔹 yıl sütunu
    private int year;

    @Enumerated(EnumType.STRING)
    @Column(name = "status") // 🔹 durum sütunu
    private Status status;

    public enum Status {
        AVAILABLE,
        BORROWED
    }

    public Book() {}

    public Book(String title, String author, int year) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.status = Status.AVAILABLE;
    }

    public int getId() {
        return id;
    }
    
   public void setId(Integer id) {
    this.id = id;
}


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return String.format(
            "ID: %d | Başlık: %s | Yazar: %s | Yıl: %d | Durum: %s",
            id,
            title != null ? title : "-",
            author != null ? author : "-",
            year,
            status != null ? status : "-"
        );
    }
}
