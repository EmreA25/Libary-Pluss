package entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "students")
public class Student {

   @Id
@Column(name = "id", nullable = false)
private Integer id;

    private String name;
    private String department;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
    private List<Loan> loans;

    public Student() {}

    public Student(String name, String department) {
        this.name = name;
        this.department = department;
    }

    // Getters & setters
    
    public int getId() { return id; }
    public void setId(Integer id) {
    this.id = id;
}
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public List<Loan> getLoans() { return loans; }
    

    public void setName(String name) { this.name = name; }
    public void setDepartment(String department) { this.department = department; }
    public void setLoans(List<Loan> loans) { this.loans = loans; }

    @Override
    public String toString() {
        return String.format("[%d] %s - %s", id, name, department);
    }
}
