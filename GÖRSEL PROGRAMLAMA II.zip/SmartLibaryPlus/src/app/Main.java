package app;

import dao.BookDao;
import dao.StudentDao;
import dao.LoanDao;
import entity.Book;
import entity.Student;
import entity.Loan;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final BookDao bookDao = new BookDao();
    private static final StudentDao studentDao = new StudentDao();
    private static final LoanDao loanDao = new LoanDao();

    public static void main(String[] args) {
        System.out.println("? SMART LIBRARY PLUS SYSTEM (Hibernate ORM)");

        while (true) {
            System.out.println("\n-------------------------");
            System.out.println("1. Kitap Ekle");
            System.out.println("2. Kitapları Listele");
            System.out.println("3. Öğrenci Ekle");
            System.out.println("4. Öğrencileri Listele");
            System.out.println("5. Kitap Ödünç Ver");
            System.out.println("6. Ödünç Listesini Görüntüle");
            System.out.println("7. Kitap Geri Teslim Al");
            System.out.println("0. Çıkış");
            System.out.println("-------------------------");
            System.out.print("Seçiminiz: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> addBook();
                case 2 -> listBooks();
                case 3 -> addStudent();
                case 4 -> listStudents();
                case 5 -> lendBook();
                case 6 -> listLoans();
                case 7 -> returnBook();
                case 0 -> {
                    System.out.println("Programdan çıkılıyor...");
                    System.exit(0);
                }
                default -> System.out.println("Geçersiz seçim!");
            }
        }
    }

    private static void addBook() {
        System.out.print("Kitap adı: ");
        String title = scanner.nextLine();
        System.out.print("Yazar: ");
        String author = scanner.nextLine();
        System.out.print("Yıl: ");
        int year = scanner.nextInt();
        scanner.nextLine();

        Book book = new Book(title, author, year);
        bookDao.save(book);
        System.out.println("✅ Kitap başarıyla kaydedildi!");
    }

    private static void listBooks() {
    List<Book> books = bookDao.getAll();

    System.out.println("\n? Kayıtlı Kitaplar:");
    System.out.println("-------------------------");

    if (books == null || books.isEmpty()) {
        System.out.println("(Henüz kitap bulunmuyor.)");
    } else {
        for (Book book : books) {
            if (book != null) {
                System.out.println(book.toString());
            } else {
                System.out.println("(Boş kayıt atlandı)");
            }
        }
    }

    System.out.println("-------------------------\n");
}

    private static void addStudent() {
        System.out.print("Öğrenci adı: ");
        String name = scanner.nextLine();
        System.out.print("Bölüm: ");
        String department = scanner.nextLine();

        Student student = new Student(name, department);
        studentDao.save(student);
        System.out.println("✅ Öğrenci başarıyla kaydedildi!");
    }

    private static void listStudents() {
    List<Student> students = studentDao.getAll();
    System.out.println("\n? Kayıtlı Öğrenciler:");
    System.out.println("-------------------------");

    if (students == null || students.isEmpty()) {
        System.out.println("(Henüz öğrenci bulunmuyor.)");
    } else {
        for (Student student : students) {
            if (student != null) {
                System.out.println(student);
            } else {
                System.out.println("(Boş kayıt atlandı)");
            }
        }
    }

    System.out.println("-------------------------");
}

    private static void lendBook() {
        System.out.print("Öğrenci ID: ");
        int studentId = scanner.nextInt();
        System.out.print("Kitap ID: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        Student student = studentDao.getById(studentId);
        Book book = bookDao.getById(bookId);

        if (student == null || book == null) {
            System.out.println("❌ Öğrenci veya kitap bulunamadı!");
            return;
        }

        if (book.getStatus() == Book.Status.BORROWED) {
            System.out.println("❌ Bu kitap zaten ödünçte!");
            return;
        }

        book.setStatus(Book.Status.BORROWED);
        bookDao.update(book);

        Loan loan = new Loan();
        loan.setBook(book);
        loan.setStudent(student);
        loan.setBorrowDate(java.sql.Date.valueOf(java.time.LocalDate.now()));
        loanDao.save(loan);

        System.out.println("📘 Kitap başarıyla ödünç verildi!");
    }

   private static void listLoans() {
    List<Loan> loans = loanDao.getAll();
    System.out.println("\n? Ödünç Listesi:");
    System.out.println("-------------------------");

    if (loans == null || loans.isEmpty()) {
        System.out.println("(Henüz ödünç kayıt yok.)");
    } else {
        for (Loan loan : loans) {
            if (loan != null && loan.getBook() != null && loan.getStudent() != null) {
                System.out.printf("Kitap: %s | Öğrenci: %s | Alış: %s | İade: %s%n",
                        loan.getBook().getTitle(),
                        loan.getStudent().getName(),
                        loan.getBorrowDate(),
                        loan.getReturnDate() != null ? loan.getReturnDate() : "-");
            } else {
                System.out.println("(Eksik veri atlandı)");
            }
        }
    }

    System.out.println("-------------------------");
}

 private static void returnBook() {
    System.out.print("İade edilecek kitap ID: ");
    int bookId = scanner.nextInt();
    scanner.nextLine();

    Book book = bookDao.getById(bookId);
    if (book == null) {
        System.out.println("❌ Kitap bulunamadı!");
        return;
    }

    if (book.getStatus() == Book.Status.AVAILABLE) {
        System.out.println("⚠️ Bu kitap zaten iade edilmiş durumda!");
        return;
    }

    // 🔹 Aktif ödünç kaydını bul
    Loan loan = loanDao.getActiveLoanByBookId(bookId);
    if (loan == null) {
        System.out.println("❌ Bu kitap için aktif ödünç kaydı bulunamadı (zaten iade edilmiş olabilir).");
        return;
    }

    // 🔹 iade tarihi kaydet
    loan.setReturnDate(new java.sql.Date(System.currentTimeMillis()));
    loanDao.update(loan);

    // 🔹 kitabı müsait hale getir
    book.setStatus(Book.Status.AVAILABLE);
    bookDao.update(book);

    System.out.println("📗 Kitap başarıyla iade alındı ve iade tarihi kaydedildi!");

    

    loan.setReturnDate(new java.sql.Date(System.currentTimeMillis()));
    loanDao.update(loan);

    book.setStatus(Book.Status.AVAILABLE);
    bookDao.update(book);

    System.out.println("📗 Kitap başarıyla iade edildi!");

loan.setReturnDate(new java.sql.Date(System.currentTimeMillis()));
loanDao.update(loan);

    // 🔹 Kitap durumunu güncelle
    book.setStatus(Book.Status.AVAILABLE);
    bookDao.update(book);

    System.out.println("📗 Kitap başarıyla iade alındı ve iade tarihi kaydedildi!");
}
}
